# QS07 Rollback CloudLib melalui Git Revert

- Scope — Satu rollback deploy CloudLib di lab lokal melalui commit revert di repo GitOps.
- Owner — C (Platform & Delivery).
- Versi/commit — Aplikasi stabil 26c77567319e657cb0b8e42402ce04a4012c5c84, digest sha256:624c490540b9db87c870069ebe5a795dfc6974875c621819aab8c68ec6c2ba72. Kandidat fa5859b6b0b71dd7812bc04d0331fe72f9646545, digest sha256:7d8639e7d46d0c11f6d76b444469ca94aa21868086629a091eccf3a7b2d74ca6. Revisi GitOps stabil c43e2ac18e8bb0846a1476973d2e921870abb9a1, kandidat 99ad4b66c676fd45f7775ad27a827df3895e43d3, dan revert 01c86d9dd9b145fda65e51b2a403fe41123b3e17.
- Timestamp — Mulai 2026-11-13T10:46:22.4604197+07:00, selesai 2026-11-13T10:49:45.4248915+07:00 (WIB).
- Metode — Verifikasi kandidat dari Gitea Actions Run #2 sudah Synced/Healthy dan merespons HTTP 200. Jalankan git revert pada commit promosi GitOps. Push revert dan pantau sinkronisasi otomatis Argo CD, pod Ready, kecocokan digest image dengan registry, dan readiness lewat Ingress setiap sekitar 3 detik.
- Observasi — GitOps kembali ke isi revisi stabil. Argo CD Synced/Healthy pada revisi revert, pod capstone-app-bcf7c4bff-hpq5t berjalan dengan digest stabil, dan readiness mengembalikan HTTP 200 UP. Durasi 202,96 detik dari observasi kandidat sesaat sebelum revert hingga kondisi akhir terverifikasi. Probe rollback tercatat 56 kali, dengan 0 respons selain HTTP 200.
- Interpretasi — Git revert memulihkan image stabil dan riwayat GitOps tetap mencatat kandidat serta revert. Gitea Actions Run #2 lulus 12 tes dan Trivy melaporkan 36 HIGH serta 0 CRITICAL sebelum publish kandidat.
- Limitasi — Satu uji pada dua versi dengan migrasi database yang sama. Resolusi waktu mengikuti interval probe. Pengukuran mencakup satu percobaan push yang gagal autentikasi dan push ulang.
- Keputusan yang didukung — Rollback QS07 lulus pada uji ini. Versi stabil sehat kembali dalam 202,96 detik, di bawah target 600 detik.

## Data pengujian

- [Observasi sebelum dan sesudah rollback](qs07-rollback-observations.json)
- [Log probe dan status Argo CD](qs07-rollback-probes.csv)
- [Screenshot Gitea Actions Run #2](gitea-actions-run-2-success.png) menunjukkan job berhasil dalam 3m11s, dari checkout hingga update tag GitOps.
- [Uji gate Trivy pada fixture](trivy-critical-gate.md)
