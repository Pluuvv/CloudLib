# Uji Pemblokiran Trivy CloudLib

- Scope — QS07, jalur gagal pada langkah scan.
- Owner — C (Platform & Delivery).
- Versi/commit — Workflow 26c77567319e657cb0b8e42402ce04a4012c5c84, Trivy 0.76.0, fixture alpine:3.10.0.
- Timestamp — 2026-11-13T10:23:45.3942917+07:00 (WIB).
- Metode — Menjalankan blok shell scan dari workflow di runner lokal, dilanjutkan dua penanda untuk publish dan update GitOps.
- Observasi — Trivy melaporkan 3 CRITICAL dan keluar dengan kode 1. Kedua penanda tidak tercapai.
- Interpretasi — Temuan CRITICAL membuat langkah scan gagal sebelum tahap berikutnya.
- Limitasi — Uji menjalankan blok shell secara terisolasi di runner dengan fixture lokal. Run #1 mencatat jalur lolos Gitea Actions. Rollback masih perlu diuji.
- Keputusan yang didukung — Gate CRITICAL dapat dipakai untuk mencegah promosi image.

## Output

```text
2026-11-13T03:23:41Z	INFO	[vuln] Vulnerability scanning is enabled
2026-11-13T03:23:41Z	INFO	Detected OS	family="alpine" version="3.10.0"
2026-11-13T03:23:41Z	INFO	[alpine] Detecting vulnerabilities...	os_version="3.10" repository="3.10" pkg_num=14
2026-11-13T03:23:41Z	INFO	Number of language-specific files	num=0
2026-11-13T03:23:41Z	WARN	This OS version is no longer supported by the distribution	family="alpine" version="3.10.0"
2026-11-13T03:23:41Z	WARN	The vulnerability detection may be insufficient because security updates are not provided

Report Summary

┌───────────────────────────────┬────────┬─────────────────┐
│            Target             │  Type  │ Vulnerabilities │
├───────────────────────────────┼────────┼─────────────────┤
│ alpine:3.10.0 (alpine 3.10.0) │ alpine │       12        │
└───────────────────────────────┴────────┴─────────────────┘
Legend:
- '-': Not scanned
- '0': Clean (no security findings detected)


alpine:3.10.0 (alpine 3.10.0)
=============================
Total: 12 (HIGH: 9, CRITICAL: 3)

┌──────────────┬────────────────┬──────────┬────────┬───────────────────┬───────────────┬──────────────────────────────────────────────────────────────┐
│   Library    │ Vulnerability  │ Severity │ Status │ Installed Version │ Fixed Version │                            Title                             │
├──────────────┼────────────────┼──────────┼────────┼───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ apk-tools    │ CVE-2021-36159 │ CRITICAL │ fixed  │ 2.10.4-r1         │ 2.10.7-r0     │ libfetch: an out of boundary read while libfetch uses strtol │
│              │                │          │        │                   │               │ to parse...                                                  │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-36159                   │
│              ├────────────────┼──────────┤        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│              │ CVE-2021-30139 │ HIGH     │        │                   │ 2.10.6-r0     │ In Alpine Linux apk-tools before 2.12.5, the tarball parser  │
│              │                │          │        │                   │               │ allows a buffer...                                           │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-30139                   │
├──────────────┼────────────────┤          │        ├───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ busybox      │ CVE-2021-28831 │          │        │ 1.30.1-r2         │ 1.30.1-r5     │ busybox: invalid free or segmentation fault via malformed    │
│              │                │          │        │                   │               │ gzip data                                                    │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-28831                   │
├──────────────┼────────────────┤          │        ├───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ libcrypto1.1 │ CVE-2020-1967  │          │        │ 1.1.1c-r0         │ 1.1.1g-r0     │ openssl: Segmentation fault in SSL_check_chain causes denial │
│              │                │          │        │                   │               │ of service                                                   │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2020-1967                    │
│              ├────────────────┤          │        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│              │ CVE-2021-23840 │          │        │                   │ 1.1.1j-r0     │ openssl: integer overflow in CipherUpdate                    │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-23840                   │
│              ├────────────────┤          │        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│              │ CVE-2021-3450  │          │        │                   │ 1.1.1k-r0     │ openssl: CA certificate check bypass with                    │
│              │                │          │        │                   │               │ X509_V_FLAG_X509_STRICT                                      │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-3450                    │
├──────────────┼────────────────┤          │        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│ libssl1.1    │ CVE-2020-1967  │          │        │                   │ 1.1.1g-r0     │ openssl: Segmentation fault in SSL_check_chain causes denial │
│              │                │          │        │                   │               │ of service                                                   │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2020-1967                    │
│              ├────────────────┤          │        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│              │ CVE-2021-23840 │          │        │                   │ 1.1.1j-r0     │ openssl: integer overflow in CipherUpdate                    │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-23840                   │
│              ├────────────────┤          │        │                   ├───────────────┼──────────────────────────────────────────────────────────────┤
│              │ CVE-2021-3450  │          │        │                   │ 1.1.1k-r0     │ openssl: CA certificate check bypass with                    │
│              │                │          │        │                   │               │ X509_V_FLAG_X509_STRICT                                      │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-3450                    │
├──────────────┼────────────────┼──────────┤        ├───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ musl         │ CVE-2019-14697 │ CRITICAL │        │ 1.1.22-r2         │ 1.1.22-r3     │ musl libc through 1.1.23 has an x87 floating-point stack     │
│              │                │          │        │                   │               │ adjustment im ......                                         │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2019-14697                   │
├──────────────┤                │          │        │                   │               │                                                              │
│ musl-utils   │                │          │        │                   │               │                                                              │
│              │                │          │        │                   │               │                                                              │
│              │                │          │        │                   │               │                                                              │
├──────────────┼────────────────┼──────────┤        ├───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ ssl_client   │ CVE-2021-28831 │ HIGH     │        │ 1.30.1-r2         │ 1.30.1-r5     │ busybox: invalid free or segmentation fault via malformed    │
│              │                │          │        │                   │               │ gzip data                                                    │
│              │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-28831                   │
└──────────────┴────────────────┴──────────┴────────┴───────────────────┴───────────────┴──────────────────────────────────────────────────────────────┘
2026-11-13T03:23:44Z	INFO	[vuln] Vulnerability scanning is enabled
2026-11-13T03:23:44Z	INFO	Detected OS	family="alpine" version="3.10.0"
2026-11-13T03:23:44Z	INFO	[alpine] Detecting vulnerabilities...	os_version="3.10" repository="3.10" pkg_num=14
2026-11-13T03:23:44Z	INFO	Number of language-specific files	num=0
2026-11-13T03:23:44Z	WARN	This OS version is no longer supported by the distribution	family="alpine" version="3.10.0"
2026-11-13T03:23:44Z	WARN	The vulnerability detection may be insufficient because security updates are not provided

Report Summary

┌───────────────────────────────┬────────┬─────────────────┐
│            Target             │  Type  │ Vulnerabilities │
├───────────────────────────────┼────────┼─────────────────┤
│ alpine:3.10.0 (alpine 3.10.0) │ alpine │        3        │
└───────────────────────────────┴────────┴─────────────────┘
Legend:
- '-': Not scanned
- '0': Clean (no security findings detected)


alpine:3.10.0 (alpine 3.10.0)
=============================
Total: 3 (CRITICAL: 3)

┌────────────┬────────────────┬──────────┬────────┬───────────────────┬───────────────┬──────────────────────────────────────────────────────────────┐
│  Library   │ Vulnerability  │ Severity │ Status │ Installed Version │ Fixed Version │                            Title                             │
├────────────┼────────────────┼──────────┼────────┼───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ apk-tools  │ CVE-2021-36159 │ CRITICAL │ fixed  │ 2.10.4-r1         │ 2.10.7-r0     │ libfetch: an out of boundary read while libfetch uses strtol │
│            │                │          │        │                   │               │ to parse...                                                  │
│            │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2021-36159                   │
├────────────┼────────────────┤          │        ├───────────────────┼───────────────┼──────────────────────────────────────────────────────────────┤
│ musl       │ CVE-2019-14697 │          │        │ 1.1.22-r2         │ 1.1.22-r3     │ musl libc through 1.1.23 has an x87 floating-point stack     │
│            │                │          │        │                   │               │ adjustment im ......                                         │
│            │                │          │        │                   │               │ https://avd.aquasec.com/nvd/cve-2019-14697                   │
├────────────┤                │          │        │                   │               │                                                              │
│ musl-utils │                │          │        │                   │               │                                                              │
│            │                │          │        │                   │               │                                                              │
│            │                │          │        │                   │               │                                                              │
└────────────┴────────────────┴──────────┴────────┴───────────────────┴───────────────┴──────────────────────────────────────────────────────────────┘
Exit code: 1
```
