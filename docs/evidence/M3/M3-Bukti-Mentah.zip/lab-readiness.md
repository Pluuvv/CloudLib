# Kesiapan Infrastruktur CloudLib

- Scope — Lab lokal Platform & Delivery.
- Owner — C (Platform & Delivery).
- Versi/commit — CloudLib c8e570afb91348135d48ff61e6eb43e3c7c81271. GitOps a0852b64c3bda08e749ffd4cfe3d0a3661f38e6f. Gitea 28.2.0, gitea-runner version v5.1.1, Argo CD v3.5.6.
- Timestamp — 2026-11-13T09:38:17.3133036+07:00 (WIB).
- Metode — Doctor paket dosen, HTTP API Gitea dan realm Keycloak, pg_isready, status Kubernetes, Git ls-remote dari Argo CD, dan HTTP GET ke smoke Ingress.
- Observasi — Doctor READY. Runner online, PostgreSQL menerima koneksi, kedua node dan pod Argo CD Ready, dan smoke Ingress menghasilkan HTTP 200.
- Interpretasi — Jalur Docker → registry → k3d → Traefik berjalan. Argo CD dapat membaca branch main GitOps melalui jaringan Docker.
- Limitasi — Pengujian memakai Nginx dari paket dosen. Pipeline, deploy CloudLib, OIDC CloudLib, QS05, QS07, dan M5 belum diuji.
- Keputusan yang didukung — Mulai adaptasi workflow dan manifest untuk deploy CloudLib.

## Output pemeriksaan

```text
Gitea: 28.2.0
Runner: capstone-local-runner online (gitea-runner version v5.1.1)
PostgreSQL host port: 5433
/var/run/postgresql:5432 - accepting connections
Keycloak OIDC discovery: HTTP 200
Registry: HTTP 200
NAME                    STATUS   ROLES           AGE     VERSION
k3d-capstone-agent-0    Ready    <none>          6m52s   v1.35.5+k3s1
k3d-capstone-server-0   Ready    control-plane   6m56s   v1.35.5+k3s1
NAME                                                READY   STATUS    RESTARTS   AGE
argocd-application-controller-0                     1/1     Running   0          4m33s
argocd-applicationset-controller-7567dc5fbb-qx9d5   1/1     Running   0          4m34s
argocd-dex-server-776dbb476d-hdljn                  1/1     Running   0          4m34s
argocd-notifications-controller-7fc8df5f57-v5z4l    1/1     Running   0          4m34s
argocd-redis-7f849fd769-ssc2s                       1/1     Running   0          4m34s
argocd-repo-server-58c976b9df-9d469                 1/1     Running   0          4m34s
argocd-server-947dccccf-fg7k8                       1/1     Running   0          4m34s
NAME                             READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/capstone-smoke   1/1     1            1           4m30s

NAME                                       CLASS     HOSTS             ADDRESS                 PORTS   AGE
ingress.networking.k8s.io/capstone-smoke   traefik   smoke.localhost   172.26.0.7,172.26.0.8   80      4m30s
registry:5000/capstone/smoke@sha256:c391603289540896337de8202f9c30a04b279ec7ff0dcaa1b80b43335a2a36ac
<!doctype html><html><body><h1>Common Capstone Infrastructure: OK</h1></body></html>

HTTP 200
a0852b64c3bda08e749ffd4cfe3d0a3661f38e6f	refs/heads/main
Gitea capstone-app main: c8e570afb91348135d48ff61e6eb43e3c7c81271
## ci/platform
```
