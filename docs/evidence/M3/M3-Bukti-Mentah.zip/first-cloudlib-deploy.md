# Deploy Pertama CloudLib

- Scope — M3 dan jalur deploy M4 pada lab lokal.
- Owner — C (Platform & Delivery).
- Versi/commit — App 26c77567319e657cb0b8e42402ce04a4012c5c84. GitOps c43e2ac18e8bb0846a1476973d2e921870abb9a1. Image registry:5000/student/capstone-app:26c77567319e657cb0b8e42402ce04a4012c5c84 (sha256:624c490540b9db87c870069ebe5a795dfc6974875c621819aab8c68ec6c2ba72).
- Timestamp — 2026-11-13T10:04:03.9574184+07:00 (WIB).
- Metode — API Gitea Actions dan registry, inspeksi Application Argo CD dan pod, serta HTTP GET readiness via Traefik.
- Observasi — Run 1 lulus. 12 tes Maven lulus. Trivy mencatat 36 HIGH dan 0 CRITICAL. Argo CD Synced/Healthy. Readiness dan koneksi database UP melalui Ingress.
- Interpretasi — SHA aplikasi dapat ditelusuri ke tag image, digest yang digunakan pod, dan revisi GitOps yang disinkronkan.
- Limitasi — Jalur pemblokiran saat CRITICAL, rollback QS07, uji hapus pod QS05, dan scrape M5 belum diuji. OIDC CloudLib masih dinonaktifkan.
- Keputusan yang didukung — Gunakan deploy ini sebagai versi awal untuk uji recovery dan rollback.

## Bukti

- [Screenshot Gitea Actions Run #1](gitea-actions-run-1-success.png) menunjukkan job berhasil dalam 5m43s, termasuk tes, build, Trivy, publish, dan update tag GitOps. Log lengkap ada di [ci-run-1.log](ci-run-1.log).
- Ringkasan temuan untuk D ada di trivy-run-1.txt.
- Ingress lokal http://cloudlib.localhost:8088/q/health/ready.

```text
Synced Healthy c43e2ac18e8bb0846a1476973d2e921870abb9a1
registry:5000/student/capstone-app@sha256:624c490540b9db87c870069ebe5a795dfc6974875c621819aab8c68ec6c2ba72
{
    "status": "UP",
    "checks": [
        {
            "name": "Database connections health check",
            "status": "UP",
            "data": {
                "<default>": "UP"
            }
        }
    ]
}
HTTP 200
```
