# QS05 Pemulihan CloudLib setelah Penghapusan Pod

- Scope — Satu kali penghapusan pod aplikasi pada lab lokal, Deployment satu replika.
- Owner — C (Platform & Delivery).
- Versi/commit — App 26c77567319e657cb0b8e42402ce04a4012c5c84, GitOps c43e2ac18e8bb0846a1476973d2e921870abb9a1, image registry:5000/student/capstone-app@sha256:624c490540b9db87c870069ebe5a795dfc6974875c621819aab8c68ec6c2ba72.
- Timestamp — 2026-11-13T10:38:33.6274634+07:00 (WIB).
- Metode — Buat eksemplar dan peminjaman sintetis melalui API, baca transaksi aktif, lalu hapus satu pod tanpa force. Kirim GET readiness melalui Traefik sekitar tiap 1 detik dengan timeout 5 detik. Ukur dari waktu pengiriman perintah hapus sampai respons HTTP 200 UP pertama setelah kegagalan, lalu verifikasi dua probe berikutnya dan pod pengganti Ready.
- Observasi — capstone-app-bcf7c4bff-ztclf digantikan oleh capstone-app-bcf7c4bff-8cwd9. Probe gagal 26 kali (HTTP 503 (26)). Readiness pulih dalam 27.64 detik. Pod pengganti Ready dalam 26.37 detik menurut timestamp Kubernetes. Respons sukses ketiga tercatat pada 29.72 detik. Transaksi pinjaman ID 1 identik sebelum dan sesudah, lalu pinjaman uji dikembalikan (HTTP 200).
- Interpretasi — Kubernetes mengganti pod dan aplikasi kembali melayani melalui Ingress. Transaksi yang sudah commit tetap dapat dibaca dari PostgreSQL.
- Limitasi — Satu pengulangan dengan satu replika, trafik berupa probe readiness. Resolusi waktu dipengaruhi interval probe. Uji ini mencakup penghapusan pod aplikasi.
- Keputusan yang didukung — QS05 Lulus pada uji ini terhadap target pemulihan ≤120 detik dengan transaksi commit tetap dapat dibaca.

## Data pengujian

- [Log probe](QS05-20261113-103827-374-probes.csv)
- [Transaksi dan identitas pod](QS05-20261113-103827-374-observations.json)
- [Event Kubernetes](QS05-20261113-103827-374-events.json)
